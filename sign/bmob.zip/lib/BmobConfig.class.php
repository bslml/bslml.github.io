<?php

/**
 * bmobConfig 配置文件
 * @author newjueqi

 * @license http://www.gnu.org/copyleft/lesser.html Distributed under the Lesser General Public License (LGPL)
 */
class BmobConfig
{
     const APPID = '85b56934cce1129e59a795da547c68e6';  //后台"应用密钥"中的Application ID
     const RESTKEY = '42257d72ebd4b8b518084fabda56ae6e';  //后台"应用密钥"中的REST API Key
     const BMOBURL = 'https://api.bmob.cn/1/';  //请勿修改
     const BMOBURLTWO = 'https://api.bmob.cn/2/';  //请勿修改




}
