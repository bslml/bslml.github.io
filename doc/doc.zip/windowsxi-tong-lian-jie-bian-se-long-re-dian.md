## Windows系统

#### 方法一：推荐使用[Proxifier](https://m.douban.com/note/183877949/)软件

#### 方法二：手动设置

首先，按下键盘的win键，就是windows 图标。然后再开始菜单中单击“设置”。

![](/assets/b8389b504fc2d5626a4b7482e11190ef76c66c1a.jpg)

然后，再出现的设置面板中，单击“网络和Internet”。

![](/assets/562c11dfa9ec8a13f090f38ff103918fa1ecc0d3.jpg)

单击“代理”。你就会看到右侧有关代理的详细设置。

![](/assets/5ab5c9ea15ce36d31744275f3cf33a87e950b119.jpg)

选择手动代理，设置代理服务器地址192.168.43.1及端口8787。

![](/assets/024f78f0f736afc318dd9b0ab519ebc4b645128f.jpg)

单击，“Internet选项”，弹出的窗口就可以设置更详细的设置了。

[](http://jingyan.baidu.com/album/47a29f24569a77c015239977.html?picindex=5)

#### 



